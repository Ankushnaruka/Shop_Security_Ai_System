import os
import numpy as np
import cv2


class CameraTamperDetector:
    def __init__(
        self,
        grid_size: int = 100,
        match_threshold: float = 0.65,
        index_threshold: int = 20,
        similarity_threshold: float = 0.7,
        black_mean_threshold: float = 105,
        white_mean_threshold: float = 110,
        covered_std_threshold: float = 15.0,
        defocus_ratio_threshold: float = 0.5,
        ir_change_confirm_frames: int = 5,
        black_white_confirm_frames: int = 10,
        tamper_confirm_frames: int = 2,
        output_dir: str = None,
    ):
        self.grid_size = grid_size
        self.match_threshold = match_threshold
        self.index_threshold = index_threshold
        self.similarity_threshold = similarity_threshold
        self.black_mean_threshold = black_mean_threshold
        self.white_mean_threshold = white_mean_threshold
        self.covered_std_threshold = covered_std_threshold
        self.defocus_ratio_threshold = defocus_ratio_threshold
        self.ir_change_confirm_frames = ir_change_confirm_frames
        self.black_white_confirm_frames = black_white_confirm_frames
        self.tamper_confirm_frames = tamper_confirm_frames
        self.output_dir = output_dir
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)

        self.points = []
        self.template_ir_check = None
        self.template_images = []
        self.histogram1 = None
        self.baseline_laplacian_var = None
        self.is_baseline_set = False

        # Counters
        self.frame_count = 0
        self.count_frame_change_value = 0   # IR mode-change persistence
        self.blackframe_count = 0
        self.whiteframe_count = 0
        self.tamper_count = 0               # movement/blocked/defocus persistence
        self.tamper_event_count = 0
        self.currently_tampered = False     # sticky state across confirm window

    # ---------- Core building blocks ----------

    @staticmethod
    def find_ir(image: np.ndarray) -> int:
        """Return 1 if the frame looks like an IR/night frame, else 0."""
        b = image[:, :, 0].astype(np.int16)
        g = image[:, :, 1].astype(np.int16)
        diff = np.abs(g - b)

        threshold = 10
        count_threshold = 1000
        count_b = int(np.count_nonzero(diff > threshold))
        return 1 if count_b < count_threshold else 0

    @staticmethod
    def get_image_histogram(image: np.ndarray) -> np.ndarray:
        if image is None or image.size == 0:
            return np.array([], dtype=np.float32)
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        hist = cv2.calcHist([hsv], [0, 1], None, [50, 60], [0, 180, 0, 256])
        cv2.normalize(hist, hist)
        return hist.flatten()

    @staticmethod
    def compute_cosine_similarity(hist1: np.ndarray, hist2: np.ndarray) -> float:
        if hist1 is None or hist2 is None or hist1.size == 0 or hist2.size == 0:
            return 0.0
        h1 = cv2.normalize(hist1, None).flatten()
        h2 = cv2.normalize(hist2, None).flatten()
        n1, n2 = np.linalg.norm(h1), np.linalg.norm(h2)
        if n1 == 0 or n2 == 0:
            return 0.0
        return float(np.dot(h1, h2) / (n1 * n2))

    @staticmethod
    def laplacian_variance(gray: np.ndarray) -> float:
        return float(cv2.Laplacian(gray, cv2.CV_64F).var())

    def get_grid_points(self, image: np.ndarray):
        num_rows = int(np.sqrt(self.grid_size))
        num_cols = num_rows
        h, w = image.shape[:2]
        tw, th = w // num_cols, h // num_rows
        return [(col * tw, row * th) for row in range(num_rows) for col in range(num_cols)]

    def get_templates(self, image: np.ndarray, points):
        if len(points) < 2:
            return []
        x0, _ = points[0]
        x1, _ = points[1]
        wh = max(1, (x1 - x0) // 3)
        h, w = image.shape[:2]
        templates = []
        for (x, y) in points:
            x_end, y_end = min(x + wh, w), min(y + wh, h)
            templates.append(image[y:y_end, x:x_end])
        return templates

    @staticmethod
    def match(frame_templates, base_templates, match_threshold: float = 0.65) -> int:
        count = 0
        for base_tpl, frame_tpl in zip(base_templates, frame_templates):
            if base_tpl.size == 0 or frame_tpl.size == 0:
                continue
            if base_tpl.shape[0] > frame_tpl.shape[0] or base_tpl.shape[1] > frame_tpl.shape[1]:
                continue
            result = cv2.matchTemplate(frame_tpl, base_tpl, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, _ = cv2.minMaxLoc(result)
            if max_val >= match_threshold:
                count += 1
        return count

    # ---------- Baseline management ----------

    def set_baseline(self, image: np.ndarray):
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        self.template_ir_check = self.find_ir(image)
        self.histogram1 = self.get_image_histogram(image)
        self.points = self.get_grid_points(image)
        self.template_images = self.get_templates(gray, self.points)
        self.baseline_laplacian_var = self.laplacian_variance(gray)
        self.is_baseline_set = True

    # ---------- Main entry point ----------

    def process_frame(self, image: np.ndarray) -> dict:
        if image is None or image.size == 0:
            return {"status": "error", "message": "empty frame", "tampered": False}

        if image.ndim != 3 or image.shape[2] != 3:
            return {"status": "error", "message": "frame is not a 3-channel color image", "tampered": False}

        if not self.is_baseline_set:
            self.set_baseline(image)
            return {
                "status": "baseline_set",
                "message": "Baseline frame captured; tamper checks start on the next frame.",
                "tampered": False,
                "frame": image,
            }

        frame_no = self.frame_count
        frame = image
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        mean_pixel_value = float(np.mean(gray))

        histogram2 = self.get_image_histogram(frame)
        frame_templates = self.get_templates(gray, self.points)

        matched = self.match(frame_templates, self.template_images, self.match_threshold)
        index = matched // 2
        similarity = self.compute_cosine_similarity(self.histogram1, histogram2)

        print(f"[frame {frame_no}] index={index} similarity={similarity:.4f}")

        result = {
            "status": "ok",
            "frame_no": frame_no,
            "index": index,
            "similarity": similarity,
            "mean_pixel_value": mean_pixel_value,
            "tampered": False,
            "note": None,
        }

        looks_suspicious = index <= self.index_threshold or similarity <= self.similarity_threshold

        if not looks_suspicious:
            result["note"] = "normal"
            self.blackframe_count = 0
            self.whiteframe_count = 0
            self.tamper_count = 0
            self.currently_tampered = False
            result["frame"] = frame
            self.frame_count += 1
            return result

        frame_ir_check = self.find_ir(frame)

        if self.template_ir_check != frame_ir_check:
            self.count_frame_change_value += 1
            result["note"] = "ir_mode_change"
            print(f"    -> ir_mode_change: count={self.count_frame_change_value}/{self.ir_change_confirm_frames}")
            if self.count_frame_change_value > self.ir_change_confirm_frames:
                self.set_baseline(frame)
                self.count_frame_change_value = 0
                result["note"] = "ir_mode_change_confirmed_rebaselined"

        elif mean_pixel_value <= self.black_mean_threshold and similarity <= 0.5 and 10 <= index <= self.index_threshold:
            self.blackframe_count += 1
            result["note"] = "possible_black_frame"
            if self.blackframe_count >= self.black_white_confirm_frames:
                result["tampered"] = True
                result["note"] = "black_frame_confirmed"
                self.tamper_event_count += 1
                self.blackframe_count = 0

        elif mean_pixel_value >= self.white_mean_threshold and similarity <= 0.6 and 10 <= index <= self.index_threshold:
            self.whiteframe_count += 1
            result["note"] = "possible_white_frame"
            if self.whiteframe_count >= self.black_white_confirm_frames:
                result["tampered"] = True
                result["note"] = "white_frame_confirmed"
                self.tamper_event_count += 1
                self.whiteframe_count = 0

        else:
            std_gray = float(np.std(gray))
            lap_var = self.laplacian_variance(gray)
            lap_ratio = (lap_var / self.baseline_laplacian_var) if self.baseline_laplacian_var else 1.0

            if std_gray < self.covered_std_threshold:
                candidate_note = "blocked_view"
            elif lap_ratio < self.defocus_ratio_threshold:
                candidate_note = "defocus"
            else:
                candidate_note = "camera_moved"

            self.tamper_count = min(self.tamper_count + 1, self.tamper_confirm_frames)
            result["note"] = f"possible_{candidate_note}"
            result["lap_ratio"] = lap_ratio
            result["std_gray"] = std_gray

            print(f"    -> {candidate_note}: tamper_count={self.tamper_count}/{self.tamper_confirm_frames} "
                  f"std_gray={std_gray:.1f} lap_ratio={lap_ratio:.2f}")

            if self.tamper_count >= self.tamper_confirm_frames:
                result["tampered"] = True
                result["note"] = f"{candidate_note}_confirmed"
                if not self.currently_tampered:
                    self.tamper_event_count += 1
                self.currently_tampered = True

        if result["tampered"]:
            frame = frame.copy()
            self._stamp_status_label(frame, tampered=True)
            result["frame"] = frame

            if self.output_dir:
                tamper_dir = os.path.join(self.output_dir, "tampered")
                os.makedirs(tamper_dir, exist_ok=True)
                tamper_path = os.path.join(tamper_dir, f"tamper_{frame_no}.jpg")
                cv2.imwrite(tamper_path, frame)
                result["tamper_image_path"] = tamper_path
        else:
            result["frame"] = frame

        self.frame_count += 1
        return result

    @staticmethod
    def _stamp_status_label(frame, tampered: bool):

        if not tampered:
            return
        h, w = frame.shape[:2]
        text = "TAMPERED"
        color = (0, 0, 255)

        overlay = frame.copy()
        cv2.rectangle(overlay, (0, 0), (w, 50), color, -1)
        cv2.addWeighted(overlay, 0.6, frame, 0.4, 0, frame)

        (text_w, _), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 1.0, 2)
        cv2.putText(
            frame, text, (max(10, (w - text_w) // 2), 35),
            cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), 2,
        )


if __name__ == "__main__":
    detector = CameraTamperDetector(output_dir="tamper_frames", tamper_confirm_frames=2)

    cap = cv2.VideoCapture("test5.mp4")

    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    frame_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    out = cv2.VideoWriter("output_inference5.mp4", fourcc, fps, (frame_w, frame_h))

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        result = detector.process_frame(frame)
        display_frame = result.get("frame", frame)
        if (display_frame.shape[1], display_frame.shape[0]) != (frame_w, frame_h):
            display_frame = cv2.resize(display_frame, (frame_w, frame_h))

        out.write(display_frame)
        cv2.imshow("Camera Tamper Detection", display_frame)

        if result.get("tampered"):
            print(f"[frame {result['frame_no']}] TAMPER DETECTED — {result['note']}")
            if result.get("tamper_image_path"):
                print(f"    saved: {result['tamper_image_path']}")
            cv2.imshow("TAMPER ALERT", display_frame)
        else:
            if cv2.getWindowProperty("TAMPER ALERT", cv2.WND_PROP_VISIBLE) > 0:
                cv2.destroyWindow("TAMPER ALERT")

        if cv2.waitKey(0) & 0xFF == ord('q'):
            break

    cap.release()
    out.release()
    cv2.destroyAllWindows()
    print(f"Inference video saved to output_inference.mp4 ({detector.frame_count} frames, "
          f"{detector.tamper_event_count} tamper events)")